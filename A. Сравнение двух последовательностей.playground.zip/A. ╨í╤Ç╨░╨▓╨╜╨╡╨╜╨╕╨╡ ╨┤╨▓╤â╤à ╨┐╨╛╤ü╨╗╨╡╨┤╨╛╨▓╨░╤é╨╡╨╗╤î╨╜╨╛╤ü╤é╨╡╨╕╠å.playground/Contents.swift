import UIKit

func isEqualCorrect(input: String) {
    guard !input.isEmpty else { print (false)
        return
    }
    let parts = input.components(separatedBy: " ")
    let one = parts[0].filter{ $0.isNumber || $0.isLetter || $0 == "." }
    let two = parts[1].filter{ $0.isNumber || $0.isLetter || $0 == "." }
    guard one.count + two.count + 1 == input.count else {print(false)
        return
    }
    
    var tempOne = ""
    for char in one {
        if char != "." {
            tempOne.append(char)
        } else {
            if !tempOne.isEmpty {
                tempOne.removeLast()
            }
        }
    }
    
    var tempTwo = ""
    for char in two {
        if char != "." {
            tempTwo.append(char)
        } else {
            if !tempTwo.isEmpty {
                tempTwo.removeLast()
            }
        }
    }
    
    if tempOne == tempTwo {
        print(true)
    } else {
        print(false)
    }
}


