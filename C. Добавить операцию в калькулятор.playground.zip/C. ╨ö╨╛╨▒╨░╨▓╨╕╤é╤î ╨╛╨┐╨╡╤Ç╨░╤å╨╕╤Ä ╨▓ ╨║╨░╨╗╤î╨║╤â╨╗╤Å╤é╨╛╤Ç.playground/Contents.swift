import UIKit

func evalArithmeticExpression(_ input: String) -> Double {
    enum Operators: String {
        case addition = "+", subtraction = "-", multiplication = "*", division = "/", pow = "^"
    }
    
    var output: [Double] = []
    var opStack: [Operators] = []
    
    for token in input.components(separatedBy: .whitespaces) {
        let number = Double(token)
        if (number != nil) {
            output += [number!]
        } else {
            let op = Operators.init(rawValue: token)!
            opStack.append(op)
        }
    }
    
    while !opStack.isEmpty {
        let topOperator = opStack.popLast()!

        let rhs = output.popLast()!, lhs = output.popLast()!
        var result: Double = 0

        switch topOperator {
        case .addition:
            result = rhs + lhs
        case .subtraction:
            result = lhs - rhs
        case .multiplication:
            result = lhs * rhs
        case .division:
            result = lhs / rhs
        case .pow:
            guard lhs > 0, rhs > 0 else { return 0}
            result = pow(lhs, rhs)
        }
        
        output.append(result)
    }
    return output[0]
}

